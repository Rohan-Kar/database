import sys

# 👇️ print all built-in module names
print(sys.builtin_module_names)
